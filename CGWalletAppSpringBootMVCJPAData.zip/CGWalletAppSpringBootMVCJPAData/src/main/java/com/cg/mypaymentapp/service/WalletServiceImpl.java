 
package com.cg.mypaymentapp.service;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Transactions;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepo1;

//import com.cg.mypaymentapp.repo.WalletRepoImpl;


@Component(value="walletService")
public class WalletServiceImpl implements WalletService
{
	@Autowired
	private WalletRepo repo;
	@Autowired
	private WalletRepo1 repo1;//=new WalletRepoImpl();
	//private WalletRepoImpl walletRepo;
	Customer customer;
	Transactions trans;

	@Transactional
	@Override
	public Customer createAccount(Customer customer){

		repo.save(customer);
		
		trans=new Transactions(customer.getMobileNo(),"Create Account",customer.getWallet().getBalance(),new Date().toString(),"Success");
		repo1.save(trans);
		return repo.save(customer);}	
	
	@Override
	public Customer showBalance(String mobileno) {

		//repo.startTransaction();
		customer=repo.getOne(mobileno);
		//repo.commitTransaction();
		if(customer==null )
			throw new InvalidInputException("Invalid mobile no ");
		else	
			return customer;}
	
	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount){
		//Customer customer=null;
		Customer customer1=new Customer();
		customer=new Customer();
		//trans=new Transactions();
		//Transactions trans1=new Transactions();
		Transactions trans2=new Transactions();
		if(sourceMobileNo.equals(targetMobileNo)){
			throw new InvalidInputException("Source and target mobile numbers are equal");}

		//repo.startTransaction();
		customer=repo.getOne(sourceMobileNo);
		customer1=repo.getOne(targetMobileNo);
		//repo.commitTransaction();
		BigDecimal balance1;
		BigDecimal balance2;

		balance1=customer.getWallet().getBalance();
		balance2=customer1.getWallet().getBalance();

		if(( balance1).compareTo(amount)>=0) {
			balance1=balance1.subtract(amount);
			customer.setWallet(new Wallet(balance1));
			repo.save(customer);
			trans=new Transactions(customer.getMobileNo(),"Fund transferred",customer.getWallet().getBalance(),new Date().toString(),"Success");
			repo1.save(trans);


			balance2=balance2.add(amount);	
			customer1.setWallet(new Wallet(balance2));
			repo.save(customer1);
			trans2=new Transactions(customer1.getMobileNo(),"Fund received",customer.getWallet().getBalance(),new Date().toString(),"Success");
			repo1.save(trans2);}

		else
			System.out.println("Insufficient balance");
		return customer ;}

	public Customer depositAmount(String mobileNo, BigDecimal amount) {

		customer=new Customer();
		trans=new Transactions();

		//repo.startTransaction();
		customer=repo.getOne(mobileNo);
		//repo.commitTransaction();

		BigDecimal dbalance;
		dbalance=customer.getWallet().getBalance();
		//if(isAmountValid(amount))
		dbalance=dbalance.add(amount);
		customer.setWallet(new Wallet(dbalance));
		repo.save(customer);
		trans=new Transactions(customer.getMobileNo(),"Deposit",customer.getWallet().getBalance(),new Date().toString(),"Success");
		repo1.save(trans);
		return customer ;}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		customer=new Customer();
		trans=new Transactions();

		//repo.startTransaction();
		customer=repo.getOne(mobileNo);
		//repo.commitTransaction();
		BigDecimal wbalance;
		wbalance=customer.getWallet().getBalance();
		//if(isAmountValid(amount))
		wbalance=wbalance.subtract(amount);
		customer.setWallet(new Wallet(wbalance));
		repo.save(customer);
		trans=new Transactions(customer.getMobileNo(),"Withdraw",customer.getWallet().getBalance(),new Date().toString(),"Success");
		repo1.save(trans);

		return customer ;}
	
	@Transactional
	public List<Transactions> recentTransactions(String mobileNumber) {
		if(!isPhoneNumbervalid(mobileNumber))
			throw new InvalidInputException("Invalid mobile number");

		else{
			//repo.startTransaction();
			List<Transactions> trans=repo1.findByMobileNumber(mobileNumber);

			//repo.commitTransaction();
			if( trans!=null)
				return trans;

			else
				throw new InvalidInputException("Invalid input");}}



	public boolean isPhoneNumbervalid( String phoneNumber ){
		
		if(phoneNumber.matches("[1-9][0-9]{9}")) {
			return true;}		
		else 
			return false;}
	
	public boolean isNameValid(String name){
		if(name.matches("^[a-zA-Z]{1,30}$")){
			return true;}
		else
			return false;}
	
	public boolean isAmountValid(BigDecimal amount){
		int val=amount.compareTo(new BigDecimal("0"));
		if(val==0|| val<0)
			return false;
		return true;}
}
